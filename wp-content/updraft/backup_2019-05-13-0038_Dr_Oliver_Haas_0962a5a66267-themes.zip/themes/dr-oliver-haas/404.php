<?php get_header(); ?>

<?php echo do_shortcode('[et_pb_section global_module="7031"][/et_pb_section]'); ?>

<?php get_footer(); ?>