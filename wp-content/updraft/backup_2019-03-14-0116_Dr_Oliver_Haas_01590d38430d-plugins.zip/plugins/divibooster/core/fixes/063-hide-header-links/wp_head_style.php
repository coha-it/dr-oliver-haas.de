<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
#et-top-navigation { visibility: hidden; }