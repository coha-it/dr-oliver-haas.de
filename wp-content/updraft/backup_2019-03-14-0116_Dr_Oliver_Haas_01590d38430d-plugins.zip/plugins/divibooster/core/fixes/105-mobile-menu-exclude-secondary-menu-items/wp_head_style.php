<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
#mobile_menu li:not([id]) { display:none !important; }