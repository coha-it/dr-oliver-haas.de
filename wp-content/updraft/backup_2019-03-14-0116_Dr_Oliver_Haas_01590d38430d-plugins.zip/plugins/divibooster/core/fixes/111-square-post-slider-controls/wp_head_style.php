<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
.et_pb_slider .et-pb-controllers a {
    border-radius: 0 !important;
}