<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
#page-container { -moz-box-shadow:none !important; -webkit-box-shadow:none !important; box-shadow:none !important; }