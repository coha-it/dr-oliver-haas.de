<!-- start Simple Custom CSS and JS -->
<script type="text/javascript">
/* Default comment here */ 




</script>
<!-- end Simple Custom CSS and JS -->
