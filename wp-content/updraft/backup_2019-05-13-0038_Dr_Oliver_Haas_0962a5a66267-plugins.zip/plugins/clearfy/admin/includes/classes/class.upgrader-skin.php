<?php
class WCL_Upgrader_Skin extends WP_Upgrader_Skin {
	public function feedback($string) {
		// @note: Keep it empty.
	}
	
	 public function header() {
		 
	 }
	 
	 public function footer() { 
		 
	 }

}
