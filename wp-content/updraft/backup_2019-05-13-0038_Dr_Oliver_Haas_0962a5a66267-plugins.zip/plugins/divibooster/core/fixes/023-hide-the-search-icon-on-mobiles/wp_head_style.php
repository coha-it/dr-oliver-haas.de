<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
@media only screen and ( max-width: 980px ) {
    #et_top_search { display:none !important; }
}