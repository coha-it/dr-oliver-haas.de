<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
@media only screen and (max-width: 479px){
.form-submit input { max-width: 280px; white-space: normal; }
}
@media only screen and (min-width: 480px) and (max-width: 768px){
.form-submit input { max-width: 400px; white-space: normal; }
}