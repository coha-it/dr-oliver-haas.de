<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
<li id="db_social_icon_add" class="customize-control customize-control-sidebar_widgets">
	<span class="button-secondary add-new-widget" tabindex="0">Add a Network</span>
</li>