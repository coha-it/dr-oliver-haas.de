<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
#top-header, #top-header a, #et-secondary-nav li li a, #top-header .et-social-icon a:before {
  font-weight: bold !important;
}