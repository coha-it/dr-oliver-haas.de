<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
.et_pb_toggle_open .et_pb_toggle_title:before {
	display: block !important;
	content: "\e04f";
}